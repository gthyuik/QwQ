package comm.control;

import comm.entity.User;
import comm.result.Result;
import comm.service.UserService;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Random;

import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/user")
public class UserControl {
    @Autowired
    private UserService userService;
    @RequestMapping("/register")
    public Result register(User user) {
        Result result = new Result();
        try {
            userService.register(user);
            result.setMsg("注册成功");
            result.setStatus(true);
        }
        catch (Exception e) {
            result.setMsg(e.getMessage()).setStatus(false);
        }
         return result;
}
    @RequestMapping("/login")
    @ResponseBody
    public Result login(@RequestParam String username,
                        @RequestParam String password,
                        @RequestParam String captcha,
                        HttpSession session) {
        Result result = new Result();
        try {
            String verifyCode = (String) session.getAttribute("verifyCode");

            if (!captcha.equalsIgnoreCase(verifyCode)) {
                result.setStatus(false).setMsg("验证码错误");
                return result;
            }

            User user = userService.login(username, password);
            if (user == null) {
                result.setStatus(false).setMsg("用户名或密码错误");
            } else {
                session.setAttribute("user", user);
                result.setStatus(true).setMsg("登录成功");
            }
        } catch (Exception e) {
            result.setStatus(false).setMsg("登录失败：" + e.getMessage());
        }
        return result;
    }


    @RequestMapping("/getImage")
    public void getImage(HttpSession session, HttpServletResponse response) throws IOException {
        // 1. 生成4位随机数字验证码
        String code = RandomStringUtils.randomNumeric(4);

        // 2. 存入 Session，供后续验证使用
        session.setAttribute("verifyCode", code);

        // 3. 创建验证码图片
        int width = 100;
        int height = 40;
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = image.createGraphics();

        // 设置背景颜色
        g.setColor(Color.WHITE);
        g.fillRect(0, 0, width, height);

        // 设置字体和颜色
        g.setColor(Color.BLACK);
        g.setFont(new Font("Arial", Font.BOLD, 24));
        g.drawString(code, 20, 28);

        // 添加干扰线
        Random rand = new Random();
        for (int i = 0; i < 5; i++) {
            g.drawLine(rand.nextInt(width), rand.nextInt(height), rand.nextInt(width), rand.nextInt(height));
        }
        // 释放资源
        g.dispose();

        // 4. 输出图片到响应流
        response.setContentType("image/png");
        ImageIO.write(image, "PNG", response.getOutputStream());
    }

}
