package comm.control;

import comm.entity.Score;
import comm.service.ScoreServiceImpl;
import comm.util.ScoreUtils;
import comm.result.Result;
import comm.service.ScoreService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/score")
public class ScoreControl {

    @Autowired
    private ScoreServiceImpl scoreService;

    // 获取所有成绩
    @GetMapping("/list")
    public Result listScores() {
        List<Score> scores = scoreService.getAllScores();
        scores.forEach(score -> score.setGrade(ScoreUtils.getGrade(score.getScore())));
        return new Result().setMsg("查询成功").setStatus(true).setData(scores);
    }


    // 添加成绩
    @PostMapping("/add")
    public Result addScore(@RequestBody Score score) {
        try {
            scoreService.addScore(score);
            return new Result().setMsg("添加成功").setStatus(true);
        } catch (Exception e) {
            return new Result().setMsg("添加失败：" + e.getMessage()).setStatus(false);
        }
    }

    // 编辑成绩
    @PostMapping("/update")
    public Result updateScore(@RequestBody Score score) {
        try {
            scoreService.updateScore(score);
            return new Result().setMsg("更新成功").setStatus(true);
        } catch (Exception e) {
            return new Result().setMsg("更新失败：" + e.getMessage()).setStatus(false);
        }
    }

    // 删除成绩
    @GetMapping("/delete")
    public Result deleteScore(@RequestParam Integer id) {
        try {
            scoreService.deleteScore(id);
            return new Result().setMsg("删除成功").setStatus(true);
        } catch (Exception e) {
            return new Result().setMsg("删除失败：" + e.getMessage()).setStatus(false);
        }
    }
}
