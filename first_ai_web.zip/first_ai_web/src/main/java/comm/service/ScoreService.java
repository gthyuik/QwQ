package comm.service;

import comm.entity.Score;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface ScoreService {
    List<Score> getAllScores();
    void addScore(Score score);
    void updateScore(Score score);
    void deleteScore(Integer id);
    Score getScoreById(Integer id);
}

