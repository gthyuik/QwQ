package comm.service;

import comm.Dao.ScoreDao;
import comm.entity.Score;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class ScoreServiceImpl implements ScoreService {

    @Autowired
    private ScoreDao scoreDao;

    @Override
    public List<Score> getAllScores() {
        return scoreDao.getAllScores();
    }

    @Override
    public void addScore(Score score) {
        scoreDao.addScore(score);
    }

    @Override
    public void updateScore(Score score) {
        scoreDao.updateScore(score);
    }

    @Override
    public void deleteScore(Integer id) {
        scoreDao.deleteScoreById(id);
    }

    @Override
    public Score getScoreById(Integer id) {
        return scoreDao.getScoreById(id);
    }
}
