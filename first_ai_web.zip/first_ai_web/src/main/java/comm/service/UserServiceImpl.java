package comm.service;

import comm.entity.User;

public interface UserServiceImpl {
    void register(User user);

    User login(String username, String password);
}
