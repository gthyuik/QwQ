package comm.service;

import comm.Dao.UserDao;
import comm.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;

@Service
@Transactional
public class UserService implements UserServiceImpl{
    @Autowired
    private UserDao userDao;
    @Override
    public void register(User user) {
        // 检查用户名是否已存在
        User existingUser = userDao.findByUsername(user.getUsername());
        if (existingUser != null) {
            throw new RuntimeException("用户名已存在");
        }

        user.setCreatetime(new Date());
        userDao.addUser(user);
    }

    @Override
    public User login(String username, String password) {
        return userDao.login(username, password);
    }
}
