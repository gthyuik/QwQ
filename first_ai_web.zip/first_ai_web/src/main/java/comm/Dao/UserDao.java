package comm.Dao;

import comm.entity.User;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface UserDao {
    void addUser(User user);

    User login(String username, String password);

    User findByUsername(String username);
}
