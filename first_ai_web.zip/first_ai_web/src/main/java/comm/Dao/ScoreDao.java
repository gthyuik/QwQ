package comm.Dao;

import comm.entity.Score;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface ScoreDao {

    List<Score> getAllScores();

    void addScore(Score score);

    void updateScore(Score score);

    void deleteScoreById(Integer id);

    Score getScoreById(Integer id);
}
