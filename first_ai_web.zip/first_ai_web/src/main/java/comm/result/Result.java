package comm.result;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
@Data
@NoArgsConstructor
@AllArgsConstructor
@Accessors(chain = true)
public class Result< T> {
    private String msg;
    private Boolean status;
    private T data;

    public static <T> Result<T> success(T data) {
        return new Result<T>().setMsg("操作成功").setStatus(true).setData(data);
    }

    public static <T> Result<T> fail(String msg) {
        return new Result<T>().setMsg(msg).setStatus(false);
    }

}
