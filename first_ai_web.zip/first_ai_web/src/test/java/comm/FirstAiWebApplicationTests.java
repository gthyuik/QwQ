package comm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstAiWebApplicationTests {

    @Test
    void contextLoads() {
    }

}
